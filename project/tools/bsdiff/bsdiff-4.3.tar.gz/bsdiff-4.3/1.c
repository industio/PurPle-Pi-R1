#include "bzlib.h"

int main(void)
{
    BZ2_bzWriteOpen();
    return 0;
}