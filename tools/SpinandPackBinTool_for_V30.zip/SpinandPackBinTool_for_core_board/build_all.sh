#!/bin/sh
echo "*********************************************************************************************"
echo "*********************************************************************************************"
echo "*********************************************************************************************"
echo "**************************** warnning: we use auto_scritps_bin.txt **************************"
echo "*********************************************************************************************"
echo "*********************************************************************************************"
echo "*********************************************************************************************"
echo "************************************project we will build:***********************************"
for BOARD in core4.3 core7
do
	for PLAT in 201 202
	do
		for SIZE in 1G 2G 4G
		do
			if [ -d images_${PLAT}_${SIZE}_${BOARD} ]; then
				echo "****************************************images_${PLAT}_${SIZE}_${BOARD}****************************************"
			fi
		done
	done
done
	echo "*********************************************************************************************"
	sleep 1

if [ ! -d output/ ]; then
	mkdir output
fi

# Annotation setenv mtdparts
./copy_PARTINFO_SPINANDINFO.sh

for BOARD in core4.3 core7
do
	for PLAT in 201 202
	do
		for SIZE in 1G 2G 4G
		do
			if [ -d images_${PLAT}_${SIZE}_${BOARD} ]; then
				./SstarMakeBin_dual_env -n SPINAND_FS35ND_${PLAT}_${SIZE}_${BOARD}.INI
				if [ ! $? == 0 ]; then
					rm output/SSD${PLAT}_${SIZE}${_BOARD}nand.bin
				fi
			fi	
		done
	done
done

if [ ! -d output/bin ]; then
	mkdir output/bin
fi
if [ ! -d output/def ]; then
	mkdir output/def
fi

mv output/*.bin output/bin
mv output/*.def output/def
