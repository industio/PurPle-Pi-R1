1.将编译生成的images拷贝到当前目录,并改名为images_202_2G;
2.修改images_202_2G/scripts/set_partition.es,注释setenv mtdparts;
3.注意images_202_2G/scripts/set_config,不要带gpio output xx;
4.执行以下命令开始制作固件:
	./SstarMakeBin_dual_env -n SPINAND_FS35ND_202_2G.INI
5.生成的output/nand.bin即为升级固件

开始升级:
	串口进入uboot
		tftp 0x21000000 nand.bin
		nand erase.chip
		nand write 0x21000000 0 ${filesize}
		reset